java -jar ETL-0.1.0.jar -S 5 -I /Users/eugene/Downloads/knoesis_output_charley/_rdf_merged -O /Users/eugene/Downloads/knoesis_output_charley/
